//square-box
    var cw = $('.square-box').width();
   $('.square-box').css({'height':cw+'px'});
   $('p.square-box').css({'width':cw+'px'});

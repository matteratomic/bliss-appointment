import {Serializable} from "./serializalble.interface";

export class Service {
	id: number;
	title: string;
}
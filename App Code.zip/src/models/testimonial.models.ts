import {Serializable} from "./serializalble.interface";

export class Testimonial {
	id: number;
	testimonial: string;
	name: string;
	image_url: string;
	created_at: string
}
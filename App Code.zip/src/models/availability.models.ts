import {Serializable} from "./serializalble.interface";

export class Availability {
	id: number;
	day: string;
	start: string;
	end: string;
}
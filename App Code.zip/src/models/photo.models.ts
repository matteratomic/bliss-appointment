import {Serializable} from "./serializalble.interface";

export class Photo {
	id: number;
	is_banner: number;
	image_url: string;
	created_at: string
}
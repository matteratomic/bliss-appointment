<?php $__env->startSection('title', __('views.admin.users.show.title', ['name' => $user->name])); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <table class="table table-striped table-hover">
            <tbody>

            <tr>
                <th>Name</th>
                <td><?php echo e($user->name); ?></td>
            </tr>

            <tr>
                <th>Email</th>
                <td>
                    <a href="mailto:<?php echo e($user->email); ?>">
                        <?php echo e($user->email); ?>

                    </a>
                </td>
            </tr>

            <tr>
                <th>Mobile</th>
                <td><?php echo e($user->mobile); ?></td>
            </tr>

            <tr>
                <th>Roles</th>
                <td>
                    <?php echo e($user->roles->pluck('name')->implode(',')); ?>

                </td>
            </tr>
            <tr>
                <th>Active?</th>
                <td>
                    <?php if($user->active): ?>
                        <span class="label label-primary">Active</span>
                    <?php else: ?>
                        <span class="label label-danger">Inactive</span>
                    <?php endif; ?>
                </td>
            </tr>

            <tr>
                <th>Created At</th>
                <td><?php echo e($user->created_at); ?> (<?php echo e($user->created_at->diffForHumans()); ?>)</td>
            </tr>

            <tr>
                <th>Last updated</th>
                <td><?php echo e($user->updated_at); ?> (<?php echo e($user->updated_at->diffForHumans()); ?>)</td>
            </tr>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
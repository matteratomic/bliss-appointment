<?php $__env->startSection('title', 'Availabilities' ); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <?php echo e(Form::open(['route'=>['admin.availabilities.save'],'method' => 'post','class'=>'form-horizontal form-label-left'])); ?>


            <div class="col-sm-12 pull-left">
                <strong>Sunday</strong>
            </div>

            <div class="form-group">
                <div class="col-md-3 col-sm-6">
                    <input id="title" type="text" class="form-control col-xs-12" name="start" placeholder="Start" required>
                </div>
                <div class="col-md-3 col-sm-6">
                    <input id="title" type="text" class="form-control col-xs-12" name="start" placeholder="End" required>
                </div>
                <div class="col-md-3 col-sm-6">
                    <input id="title" type="text" class="form-control col-xs-12" name="start" placeholder="Start" required>
                </div>
                <div class="col-md-3 col-sm-6">
                    <input id="title" type="text" class="form-control col-xs-12" name="start" placeholder="End" required>
                </div>
            </div>

            <div class="col-sm-12 pull-left">
                <strong>Monday</strong>
            </div>

            <div class="form-group">
                <div class="col-md-3 col-sm-6">
                    <input id="title" type="text" class="form-control col-xs-12" name="start" placeholder="Start" required>
                </div>
                <div class="col-md-3 col-sm-6">
                    <input id="title" type="text" class="form-control col-xs-12" name="start" placeholder="End" required>
                </div>
                <div class="col-md-3 col-sm-6">
                    <input id="title" type="text" class="form-control col-xs-12" name="start" placeholder="Start" required>
                </div>
                <div class="col-md-3 col-sm-6">
                    <input id="title" type="text" class="form-control col-xs-12" name="start" placeholder="End" required>
                </div>
            </div>

            <div class="form-group">
                <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                    <a class="btn btn-primary" href="<?php echo e(URL::previous()); ?>">Back</a>
                    <button type="submit" class="btn btn-success"> Save</button>
                </div>
            </div>
            <?php echo e(Form::close()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
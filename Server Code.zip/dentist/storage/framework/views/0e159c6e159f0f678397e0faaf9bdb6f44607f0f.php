<?php $__env->startSection('content'); ?>
    <!-- page content -->
    <!-- top tiles -->
    <div class="row tile_count">
        <div class="col-md-3 col-sm-4 col-xs-6 tile_stats_count text-center">
            <span class="count_top"><i class="fa fa-users"></i> <?php echo e(__('views.admin.dashboard.count_0')); ?></span>
            <div class="count green"><?php echo e($counts['users']); ?></div>
        </div>
        <div class="col-md-3 col-sm-4 col-xs-6 tile_stats_count text-center">
            <span class="count_top"><i class="fa fa-address-card"></i> Upcoming Appointments</span>
            <div>
                <span class="count green"><?php echo e($counts['upcoming_appointments']); ?></span>
            </div>
        </div>
        <div class="col-md-3 col-sm-4 col-xs-6 tile_stats_count text-center">
            <span class="count_top"><i class="fa fa-envelope "></i> Support Requests</span>
            <div>
                <span class="count green"><?php echo e($counts['support_count']); ?></span>
            </div>
        </div>
        <div class="col-md-3 col-sm-4 col-xs-6 tile_stats_count text-center">
            <span class="count_top"><i class="fa fa-rss"></i> Blogs Count</span>
            <div>
                <span class="count green"><?php echo e($counts['blogs_count']); ?></span>
            </div>
        </div>
    </div>
    <!-- /top tiles -->

    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div id="log_activity" class="dashboard_graph">

                <div class="row x_title">
                    <div class="col-md-6">
                        <h3>Appointments by day</h3>
                    </div>
                    <div class="col-md-6">
                        <div class="date_piker pull-right"
                             style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc">
                            <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>
                            <span class="date_piker_label">
                                <?php echo e(\Carbon\Carbon::now()->addDays(-6)->format('F j, Y')); ?> - <?php echo e(\Carbon\Carbon::now()->format('F j, Y')); ?>

                            </span>
                            <b class="caret"></b>
                        </div>
                    </div>
                </div>

                <div class="col-xs-12">
                    <div class="chart demo-placeholder" style="width: 100%; height:460px;"></div>
                </div>

                <div class="clearfix"></div>
            </div>
        </div>

    </div>
    <br />

    
        
            
                
                    
                    
                
                
                    
                        
                            
                            
                                
                                    
                                
                                
                                    
                                
                            
                        
                        
                            
                                
                                
                            
                            
                                
                                    
                                        
                                            
                                                
                                                     
                                                
                                            
                                        
                                        
                                    
                                    
                                        
                                            
                                                
                                                    
                                                
                                            
                                        
                                        
                                    
                                    
                                        
                                            
                                                
                                                    
                                                
                                            
                                        
                                        
                                    
                                    
                                        
                                            
                                                
                                                     
                                                
                                            
                                        
                                        
                                    
                                
                            
                        
                    
                
            
        
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    ##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
    <?php echo e(Html::script(mix('assets/admin/js/dashboard.js'))); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    ##parent-placeholder-bf62280f159b1468fff0c96540f3989d41279669##
    <?php echo e(Html::style(mix('assets/admin/css/dashboard.css'))); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('title', 'Availability' ); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <?php echo e(Form::open(['route'=>['admin.availabilities.update', $availability->id],'method' => 'put','class'=>'form-horizontal form-label-left'])); ?>


            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">
                    Day
                    <span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <select name="day">
                        <option <?php if($availability->day == "SUN"): ?> selected <?php endif; ?> value="SUN">Sunday</option>
                        <option <?php if($availability->day == "MON"): ?> selected <?php endif; ?> value="MON">Monday</option>
                        <option <?php if($availability->day == "TUE"): ?> selected <?php endif; ?> value="TUE">Tuesday</option>
                        <option <?php if($availability->day == "WED"): ?> selected <?php endif; ?> value="WED">Wednesday</option>
                        <option <?php if($availability->day == "THU"): ?> selected <?php endif; ?> value="THU">Thursday</option>
                        <option <?php if($availability->day == "FRI"): ?> selected <?php endif; ?> value="FRI">Friday</option>
                        <option <?php if($availability->day == "SAT"): ?> selected <?php endif; ?> value="SAT">Saturday</option>
                    </select>
                    <?php if($errors->has('day')): ?>
                        <ul class="parsley-errors-list filled">
                            <?php $__currentLoopData = $errors->get('day'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="parsley-required"><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="start">
                    Start Time
                    <span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <input id="start" type="text" value="<?php echo e($availability->start); ?>"
                           class="form-control col-md-7 col-xs-12 <?php if($errors->has('start')): ?> parsley-error <?php endif; ?>"
                           name="start" required>(Format-> HH:MM)
                    <?php if($errors->has('start')): ?>
                        <ul class="parsley-errors-list filled">
                            <?php $__currentLoopData = $errors->get('start'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="parsley-required"><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="end">
                    End Time
                    <span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <input id="end" type="text" value="<?php echo e($availability->end); ?>"
                           class="form-control col-md-7 col-xs-12 <?php if($errors->has('end')): ?> parsley-error <?php endif; ?>"
                           name="end" required>(Format-> HH:MM)
                    <?php if($errors->has('end')): ?>
                        <ul class="parsley-errors-list filled">
                            <?php $__currentLoopData = $errors->get('end'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="parsley-required"><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group">
                <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                    <a class="btn btn-primary" href="<?php echo e(URL::previous()); ?>">Back</a>
                    <button type="submit" class="btn btn-success"> Save</button>
                </div>
            </div>
            <?php echo e(Form::close()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
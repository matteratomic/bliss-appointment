<?php $__env->startSection('title', 'Upcoming Appointments'); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-sm-12">
        <a class="btn btn-primary" href="<?php echo e(route('admin.appointments.create')); ?>">Add</a>
    </div>

    <div class="row">
        <table class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0"
               width="100%">
            <thead>
            <tr>
                <th>User ID</th>
                <th>Scheduled On</th>
                <th>Service Id</th>
                <th>Status</th>
                <th>Created At</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><a target="_blank" href="<?php echo e(route('admin.users.show', [$appointment->user_id])); ?>"><?php echo e($appointment->user->name); ?></a></td>
                    <td><?php echo e($appointment->scheduled_on); ?></td>
                    <td><?php echo e($appointment->service->title); ?></td>
                    <td><?php echo e($appointment->status); ?></td>
                    <td><?php echo e($appointment->created_at); ?></td>
                    <td>
                        <a class="btn btn-xs btn-info" href="<?php echo e(route('admin.appointments.edit', [$appointment->id])); ?>" data-toggle="tooltip" data-placement="top" data-title="Edit">
                            <i class="fa fa-pencil"></i>
                        </a>
                        <a class="btn btn-xs btn-danger" href="<?php echo e(route('admin.appointments.destroy', [$appointment->id])); ?>" data-toggle="tooltip" data-placement="top" data-title="Delete">
                            <i class="fa fa-trash"></i>
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="pull-right">
            <?php echo e($appointments->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
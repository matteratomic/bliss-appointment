<?php
return [
    'paginate_per_page' => env('PAGINATE_PER_PAGE', 15)
];